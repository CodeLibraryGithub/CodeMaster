<?php
	/**
		* Returns the list of policies.
	*/
	require 'database.php';
	$json = [];
	$sql = "SELECT * FROM taskslist";
	$users = "SELECT id, name FROM users";
	if($result = mysqli_query($con,$users))
	{
		$i = 0;
		while($row = mysqli_fetch_assoc($result))
		{
			$json['users'][$i]['id']    = $row['id'];
			$json['users'][$i]['name'] = $row['name'];
			$i++;
		}
		
		//echo json_encode($json['users']);
	}
	if($result = mysqli_query($con,$sql))
	{
		$i = 0;
		while($row = mysqli_fetch_assoc($result))
		{
			$json['policies'][$i]['id']    = $row['id'];
			$json['policies'][$i]['name'] = $row['name'];
			$json['policies'][$i]['assignedTo'] = $row['assignedTo'];
			$json['policies'][$i]['date_start'] = $row['date_start'];
			$json['policies'][$i]['date_end'] = $row['date_end'];
			$i++;
		}
		
		echo json_encode($json['policies']);
	}
	else
	{
		http_response_code(404);
	}
?>