<?php
	require 'database.php';
	
	// Get the posted data.
	$postdata = file_get_contents("php://input");
	
	if(isset($postdata) && !empty($postdata))
	{
		// Extract the data.
		$request = json_decode($postdata);
		
		
		// Validate.
		if(trim($request->name) === '')
		{
			return http_response_code(400);
		}
		
		// Sanitize.
		$name = mysqli_real_escape_string($con, trim($request->name));
		$date_start = mysqli_real_escape_string($con,$request->date_start);
		$date_end = mysqli_real_escape_string($con, $request->date_end);
		$assignedTo = mysqli_real_escape_string($con, $request->assignedTo);
		
		
		// Create.
		$sql = "INSERT INTO `taskslist`(`id`,`name`,`date_start`,`date_end`, `assignedTo`) VALUES (null,'{$name}','{$date_start}','{$date_end}', '{$assignedTo}')";
		
		if(mysqli_query($con,$sql))
		{
			http_response_code(201);
			$policy = [
			'name' => $name,
			'date_start' => $date_start,
			'date_end' => $date_end,
			'id'    => mysqli_insert_id($con)
			];
			echo json_encode($policy);
		}
		else
		{
			http_response_code(422);
		}
	}
?>