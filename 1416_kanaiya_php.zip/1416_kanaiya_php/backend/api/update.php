<?php
	require 'database.php';
	
	// Get the posted data.
	$postdata = file_get_contents("php://input");
	
	if(isset($postdata) && !empty($postdata))
	{
		// Extract the data.
		$request = json_decode($postdata);
		// Validate.
		if ((int)$request->id < 1 || trim($request->name) == '') {
			return http_response_code(400);
		}
		
		// Sanitize.
		$id    = mysqli_real_escape_string($con, (int)$request->id);
		$name = mysqli_real_escape_string($con, trim($request->name));
		$date_start = mysqli_real_escape_string($con, $request->date_start);
		$date_end = mysqli_real_escape_string($con, $request->date_end);
		$assignedTo = mysqli_real_escape_string($con, $request->assignedTo);
		
		// Update.
	$sql = "UPDATE `taskslist` SET `name` = '{$name}',`date_start`='$date_start',`assignedTo`='{$assignedTo}', `date_end`='$date_end' WHERE `id` = '{$id}' LIMIT 1";
		
		if(mysqli_query($con, $sql))
		{
			http_response_code(204);
		}
		else
		{
			return http_response_code(422);
		}  
	}
?>