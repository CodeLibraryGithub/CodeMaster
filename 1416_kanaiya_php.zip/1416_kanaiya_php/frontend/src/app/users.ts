export  class  Users {
    id: number;
    name:  string;
}