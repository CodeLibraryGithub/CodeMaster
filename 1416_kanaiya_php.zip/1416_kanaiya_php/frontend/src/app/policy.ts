export  class  Policy {
    id: number;
    name:  string;
    date_start:  string;
    date_end:  string;
	assignedTo:  number;
}